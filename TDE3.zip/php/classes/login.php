<?php

include_once('conexao.php');

class login extends conexao{

    public function logar(?string $usuario,$senha){
        //$senha = md5($senha);
        $SQL = "SELECT * FROM usuario WHERE nome_usuario = '$usuario' AND senha = '$senha'";
       
        try{
            $SLC = $this->Select($SQL);
            $Dados["confirmacao"] = "";
            $Dados["nome"] = "";
            $Dados["email"] = "";
            while($registro = mysqli_fetch_assoc($SLC)){
                $Dados["nome"] = $registro["nome_usuario"];
                $Dados["email"] = $registro["email"];
            }
            $Dados["confirmacao"] = "LOGIN EFETUADO";
            
        }
        catch(Exception $e){
            if($e->getMessage()){
                $Dados["confirmacao"] = $e->getMessage();
                //echo 'Erro: ',  $e->getMessage(), "\n";
            }else{
                $Dados["confirmacao"] = "Algo deu errado";
            }
            //echo 'Exceção capturada: ',  $e->getMessage(), "\n";
        }
        return $Dados;

    }
}

// $teste = new login("localhost:3306","root","","tde_web");
// $select = $teste->logar('gio@21.com','123456');
?>